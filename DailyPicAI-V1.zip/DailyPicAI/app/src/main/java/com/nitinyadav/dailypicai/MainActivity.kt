package com.nitinyadav.dailypicai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(this)
        setContent { DailyPicApp(this) }
    }
}

private const val PREFS = "daily_pic"
private const val KEY_URIS = "uris"

@Composable
fun DailyPicApp(context: Context) {
    var uris by remember { mutableStateOf(loadUris(context)) }
    var selected by remember { mutableStateOf<Uri?>(null) }
    var style by remember { mutableStateOf(EditStyle.CINEMATIC) }
    var caption by remember { mutableStateOf("") }
    var edited by remember { mutableStateOf<Bitmap?>(null) }
    var message by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(PickMultipleVisualMedia(50)) { picked ->
        if (picked.isNotEmpty()) {
            picked.forEach { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            }
            uris = (uris + picked).distinct()
            saveUris(context, uris)
            message = "${picked.size} photos added"
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("DailyPic AI") }) }
        ) { pad ->
            Column(
                Modifier.padding(pad).padding(16.dp).fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Your daily Instagram assistant", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { picker.launch(PickVisualMediaRequest(PickVisualMedia.ImageOnly)) }) {
                        Text("Add Photos")
                    }
                    OutlinedButton(onClick = {
                        val next = chooseNext(uris)
                        selected = next
                        if (next != null) {
                            edited = editBitmap(context, next, style)
                            caption = CaptionEngine.generate(style)
                        }
                    }, enabled = uris.isNotEmpty()) { Text("Create Today's Post") }
                }

                if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)

                if (uris.isNotEmpty()) {
                    Text("Photo library (${uris.size})", style = MaterialTheme.typography.titleSmall)
                    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(220.dp)) {
                        items(uris) { uri -> PhotoThumb(context, uri) }
                    }
                }

                Text("AI style", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EditStyle.values().forEach { s ->
                        FilterChip(selected = style == s, onClick = { style = s }, label = { Text(s.label) })
                    }
                }

                edited?.let { bitmap ->
                    Text("Preview", style = MaterialTheme.typography.titleSmall)
                    Image(bitmap.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(260.dp), contentScale = ContentScale.Fit)
                    OutlinedTextField(caption, { caption = it }, label = { Text("Caption") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { shareToInstagram(context, selected, caption) }) { Text("Share to Instagram") }
                        OutlinedButton(onClick = {
                            scheduleDaily(context)
                            message = "Daily reminder scheduled."
                        }) { Text("Schedule Daily") }
                    }
                }
            }
        }
    }
}


@Composable
fun PhotoThumb(context: Context, uri: Uri) {
    val bmp = remember(uri) { decode(context, uri, 300) }
    if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.padding(3.dp).fillMaxWidth().height(95.dp), contentScale = ContentScale.Crop)
    else Box(Modifier.padding(3.dp).fillMaxWidth().height(95.dp).background(MaterialTheme.colorScheme.surfaceVariant))
}

enum class EditStyle(val label: String) { CINEMATIC("Cinematic"), PRO("Instagram Pro"), VINTAGE("Vintage"), NATURAL("Natural") }

object CaptionEngine {
    private val captions = mapOf(
        EditStyle.CINEMATIC to listOf("Some moments don't need an explanation. ✨", "Just another frame from the story. 🎬"),
        EditStyle.PRO to listOf("Confidence looks good in every frame. ✨", "A little style, a little attitude."),
        EditStyle.VINTAGE to listOf("Old-school mood, new memories. 📸", "Some frames never go out of style."),
        EditStyle.NATURAL to listOf("Keeping it simple. 🌿", "No filter on the moment, just good vibes. ☀️")
    )
    fun generate(style: EditStyle): String = captions[style]!!.random() + "\n\n#DailyPic #Photography #Vibes #Instagram"
}

fun chooseNext(uris: List<Uri>): Uri? = uris.firstOrNull()

fun decode(context: Context, uri: Uri, max: Int): Bitmap? = try {
    context.contentResolver.openInputStream(uri).use { input ->
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeStream(input, null, opts)
        val sample = maxOf(1, maxOf(opts.outWidth, opts.outHeight) / max)
        context.contentResolver.openInputStream(uri).use { second ->
            BitmapFactory.decodeStream(second, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    }
} catch (_: Exception) { null }

fun editBitmap(context: Context, uri: Uri, style: EditStyle): Bitmap? {
    val source = decode(context, uri, 1600) ?: return null
    val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    val matrix = ColorMatrix()
    when (style) {
        EditStyle.CINEMATIC -> matrix.setSaturation(0.9f)
        EditStyle.PRO -> matrix.setSaturation(1.15f)
        EditStyle.VINTAGE -> { matrix.setSaturation(0.7f); matrix.postConcat(ColorMatrix(floatArrayOf(1f,0f,0f,0f,10f, 0f,1f,0f,0f,5f, 0f,0f,0.9f,0f,-5f, 0f,0f,0f,1f,0f))) }
        EditStyle.NATURAL -> matrix.setSaturation(1.05f)
    }
    paint.colorFilter = ColorMatrixColorFilter(matrix)
    canvas.drawBitmap(source, 0f, 0f, paint)
    return out
}

fun shareToInstagram(context: Context, uri: Uri?, caption: String) {
    if (uri == null) return
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/*"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_TEXT, caption)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        `package` = "com.instagram.android"
    }
    try { context.startActivity(intent) } catch (_: Exception) {
        context.startActivity(Intent.createChooser(intent, "Share post"))
    }
}

fun loadUris(context: Context): List<Uri> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    .getString(KEY_URIS, "")!!.split("\n").filter { it.isNotBlank() }.map { Uri.parse(it) }

fun saveUris(context: Context, uris: List<Uri>) {
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_URIS, uris.joinToString("\n") { it.toString() }).apply()
}

fun scheduleDaily(context: Context) {
    val request = PeriodicWorkRequestBuilder<DailyReminderWorker>(24, TimeUnit.HOURS)
        .setInitialDelay(1, TimeUnit.HOURS)
        .build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork("daily_post", ExistingPeriodicWorkPolicy.UPDATE, request)
}

class DailyReminderWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = androidx.core.app.NotificationCompat.Builder(applicationContext, "daily_pic")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("DailyPic AI")
            .setContentText("Your daily Instagram post is ready to create.")
            .setAutoCancel(true).build()
        manager.notify(1001, notification)
        return Result.success()
    }
}

fun createChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel("daily_pic", "DailyPic reminders", NotificationManager.IMPORTANCE_DEFAULT)
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
