# DailyPic AI — Android V1

A starter Android app for storing selected photos, generating a local edited preview, creating captions, sharing to Instagram, and scheduling a daily reminder.

## Build
1. Open this folder in Android Studio Quail 4 (or newer compatible Android Studio).
2. Use JDK 17.
3. Let Gradle sync.
4. Run on an Android 8+ device.

## V1 features
- Android Photo Picker: add up to 50 photos per selection.
- Local photo URI library.
- Four local edit presets: Cinematic, Instagram Pro, Vintage, Natural.
- Caption generator with hashtags.
- Instagram share handoff (user still confirms the post).
- WorkManager daily reminder.

## Important limitation
V1 does NOT silently publish to Instagram. Automatic publishing requires Meta/Instagram API integration and the correct account/API permissions. The current app deliberately uses the Android share flow so the user remains in control.

## Next build
- Room database + photo metadata.
- Real AI image editing backend.
- AI caption API.
- Meta Graph API authentication and publishing.
- Exact daily-time scheduling and post history.
